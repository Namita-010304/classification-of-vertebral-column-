#using ANN 

# Load necessary libraries
install.packages("neuralnet")
library(neuralnet)
library(dplyr)

# Load the dataset
data <- read.csv(file.choose())
str(data)

colnames(data)

#Convert target variable 'class_output' to binary numeric format
# Assuming 'Abnormal' as 1 and 'Normal' as 0 for classification
data$class_output <- ifelse(data$class_output == "Abnormal", 1, 0)

# Normalize numeric features
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

# Apply normalization to all numeric columns except the target ('class_output')
data_norm <- as.data.frame(lapply(data[, 1:6], normalize))  # Select only feature columns (1 to 6)

# Add the target variable back to the normalized data
data_norm$class_output <- data$class_output

# Split the data into training (75%) and testing (25%) sets
set.seed(123)  # For reproducibility
train_index <- sample(1:nrow(data_norm), 0.75 * nrow(data_norm))
train_data <- data_norm[train_index, ]
test_data <- data_norm[-train_index, ]

# Build the formula dynamically based on feature columns
formula <- as.formula(paste("class_output ~", paste(names(data_norm)[1:6], collapse = " + ")))

# Train the ANN model with one hidden layer of 5 neurons
ann_model <- neuralnet(
  formula,
  data = train_data,
  hidden = 5,
  linear.output = FALSE,
  stepmax = 1e6  # To handle convergence for larger datasets
)

# Plot the trained neural network
plot(ann_model) #okk

# Predict on the test dataset
model_results <- predict(ann_model, test_data[, 1:6])  # Use only the feature columns for prediction

# Process the prediction results correctly
predicted_class <- ifelse(model_results > 0.5, 1, 0)  # Directly threshold the prediction matrix/vector

# Evaluate performance
actual_class <- test_data$class_output
confusion_matrix <- table(Predicted = predicted_class, Actual = actual_class)
print(confusion_matrix)

# Calculate accuracy
accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
print(paste("Accuracy:", round(accuracy * 100, 2), "%"))










#decision tree


# Load necessary libraries
install.packages("rpart")
install.packages("rpart.plot")
library(rpart)
library(rpart.plot)

# Load dataset
mydata <- read.csv(file.choose())

# Case  With pelvic_incidence
features_case1 <- c("pelvic_incidence", "lumbar_lordosis_angle", "pelvic_radius", "degree_spondylolisthesis")
target <- "class_output"

# Splitting dataset into training and testing (70% training, 30% testing)
set.seed(42)
indexes <- sample(1:nrow(mydata), 0.7 * nrow(mydata))
train_data_case1 <- mydata[indexes, ]
test_data_case1 <- mydata[-indexes, ]

# Train Decision Tree for Case 1
tree_case1 <- rpart(class_output ~ pelvic_incidence + lumbar_lordosis_angle + pelvic_radius + degree_spondylolisthesis, 
                    data = train_data_case1, method = "class")

# Visualize the Decision Tree
rpart.plot(tree_case1, main = "Decision Tree - Case 1")

# Make predictions for Case 1
predictions_case1 <- predict(tree_case1, test_data_case1, type = "class")

# Evaluate the model for Case 1
conf_matrix_case1 <- table(test_data_case1$class_output, predictions_case1)
print("Confusion Matrix - Case 1")
print(conf_matrix_case1)
accuracy_case1 <- sum(diag(conf_matrix_case1)) / sum(conf_matrix_case1)
print(paste("Accuracy - Case 1:", round(accuracy_case1, 4)))






# svm 

# Set working directory and load dataset
getwd()
dataset <- read.csv(file.choose()) 
# Replace with actual dataset path
str(dataset)

# Encoding target variable as a factor
dataset$class_output <- factor(dataset$class_output, levels = unique(dataset$class_output))

# Case 1: With pelvic_incidence
features_case1 <- c("pelvic_incidence", "lumbar_lordosis_angle", "pelvic_radius", "degree_spondylolisthesis")
target <- "class_output"

dataset_case1 <- dataset[, c(features_case1, target)]

# Splitting the dataset into training and test sets
install.packages("caTools")
library(caTools)
set.seed(123)
split <- sample.split(dataset_case1$class_output, SplitRatio = 0.7)
training_set_case1 <- subset(dataset_case1, split == TRUE)
test_set_case1 <- subset(dataset_case1, split == FALSE)

# Fitting SVM to the training set for Case 1
library(e1071)
classifier_case1 <- svm(formula = class_output ~ .,
                        data = training_set_case1,
                        type = 'C-classification',
                        kernel = 'linear')

# Predicting test set results for Case 1
y_pred_case1 <- predict(classifier_case1, newdata = test_set_case1[, -5])

# Making the confusion matrix for Case 1
cm_case1 <- table(test_set_case1$class_output, y_pred_case1)
print("Confusion Matrix - Case 1")
print(cm_case1)



#k means clustering 


# Install and load necessary libraries
install.packages("cluster")
library(cluster)

# Load the dataset
dataset <- read.csv(file.choose())  # Replace with actual path to your dataset

# Case 1: With pelvic_incidence
features_case1 <- c("pelvic_incidence", "lumbar_lordosis_angle", "pelvic_radius", "degree_spondylolisthesis")
dataset_case1 <- dataset[, features_case1]

# Fitting K-Means clustering model for Case 1
set.seed(240)
kmeans_case1 <- kmeans(dataset_case1, centers = 3, nstart = 20)  # centers = number of clusters, nstart = number of random initializations

# Cluster identification for each observation
print("Cluster Assignments - Case 1")
print(kmeans_case1$cluster)
print("Cluster Centers - Case 1")
print(kmeans_case1$centers)

# Confusion Matrix for Case 1
cm_case1 <- table(dataset$class_output, kmeans_case1$cluster)
print("Confusion Matrix - Case 1")
print(cm_case1)

# Plotting clusters for Case 1
plot(dataset_case1[c("pelvic_incidence", "lumbar_lordosis_angle")],
     col = kmeans_case1$cluster,
     main = "K-Means Clustering with 3 Clusters (Case 1)",
     xlab = "Pelvic Incidence",
     ylab = "Lumbar Lordosis Angle")

points(kmeans_case1$centers[, c("pelvic_incidence", "lumbar_lordosis_angle")],
       col = 1:3,
       pch = 8,
       cex = 3)

y_kmeans_case1 <- kmeans_case1$cluster
clusplot(dataset_case1[, c("pelvic_incidence", "lumbar_lordosis_angle")],
         y_kmeans_case1,
         lines = 0,
         shade = TRUE,
         color = TRUE,
         labels = 2,
         plotchar = FALSE,
         span = TRUE,
         main = "Cluster Plot for Case 1",
         xlab = "Pelvic Incidence",
         ylab = "Lumbar Lordosis Angle")




########plotting accuracies of all the models



# Load Required Libraries
library(ggplot2)
library(rpart)
library(rpart.plot)
library(neuralnet)
library(e1071)
library(class)

# Load the Dataset
data <- read.csv(file.choose())  # Choose the vertebral column dataset
str(data)

# Convert Target Variable 'class_output' to Binary Numeric Format
data$class_output <- ifelse(data$class_output == "Abnormal", 1, 0)

# Initialize Accuracy Data
model_accuracies <- data.frame(
  Model = c("Decision Tree", "ANN", "SVM", "K-Means Clustering"),
  Accuracy = c(NA, NA, NA, NA) # Placeholder for accuracies
)

# ------------------------------
# 1. Decision Tree Model
# ------------------------------
set.seed(42)
indexes <- sample(1:nrow(data), 0.7 * nrow(data))
train <- data[indexes, ]
test <- data[-indexes, ]

# Decision Tree Model
target <- class_output ~ pelvic_incidence + lumbar_lordosis_angle + pelvic_radius + degree_spondylolisthesis
tree <- rpart(target, data = train, method = "class")
pred_tree <- predict(tree, test, type = "class")

# Accuracy
conf_matrix_tree <- table(test$class_output, pred_tree)
accuracy_tree <- sum(diag(conf_matrix_tree)) / sum(conf_matrix_tree)
model_accuracies$Accuracy[1] <- accuracy_tree

# ------------------------------
# 2. ANN Model
# ------------------------------
# Normalize Features
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

# Normalize Data (Exclude the Target Variable)
data_norm <- as.data.frame(lapply(data[, 1:6], normalize))  # Select feature columns
data_norm$class_output <- data$class_output

# Split Data
train_index <- sample(1:nrow(data_norm), 0.75 * nrow(data_norm))
train_data <- data_norm[train_index, ]
test_data <- data_norm[-train_index, ]

# Build the ANN Formula Dynamically
formula <- as.formula(paste("class_output ~", paste(names(data_norm)[1:6], collapse = " + ")))

# Train the ANN Model
ann_model <- neuralnet(
  formula,
  data = train_data,
  hidden = 5,  # Single hidden layer with 5 neurons
  linear.output = FALSE,
  stepmax = 1e6  # Handle convergence issues for larger datasets
)

# Predict
ann_pred <- predict(ann_model, test_data[, 1:6])  # Use feature columns for prediction
predicted_class <- ifelse(ann_pred > 0.5, 1, 0)  # Convert probabilities to binary classification

# Accuracy
conf_matrix_ann <- table(Predicted = predicted_class, Actual = test_data$class_output)
accuracy_ann <- sum(diag(conf_matrix_ann)) / sum(conf_matrix_ann)
model_accuracies$Accuracy[2] <- accuracy_ann

# ------------------------------
# 3. SVM Model
# ------------------------------
train$class_output <- factor(train$class_output)
test$class_output <- factor(test$class_output)

# Train SVM Model
svm_classifier <- svm(
  formula = class_output ~ pelvic_incidence + lumbar_lordosis_angle + pelvic_radius + degree_spondylolisthesis,
  data = train,
  type = "C-classification",
  kernel = "linear"
)
svm_pred <- predict(svm_classifier, newdata = test)

# Accuracy
conf_matrix_svm <- table(test$class_output, svm_pred)
accuracy_svm <- sum(diag(conf_matrix_svm)) / sum(conf_matrix_svm)
model_accuracies$Accuracy[3] <- accuracy_svm

# ------------------------------
# 4. K-Means Clustering
# ------------------------------

library(cluster)

# Clustering
features_case1 <- c("pelvic_incidence", "lumbar_lordosis_angle", "pelvic_radius", "degree_spondylolisthesis")
dataset_case1 <- dataset[, features_case1]

set.seed(240)
kmeans_model <- kmeans(dataset_case1, centers = 3, nstart = 20)

# Confusion Matrix
conf_matrix_kmeans <- table(dataset$class_output, kmeans_model$cluster)

# Adjust Clusters (Matching Predicted Labels to Actual Labels)
map_clusters <- apply(conf_matrix_kmeans, 2, which.max)
pred_kmeans <- map_clusters[kmeans_model$cluster]

# Accuracy
accuracy_kmeans <- mean(pred_kmeans == as.numeric(dataset$class_output))
model_accuracies$Accuracy[4] <- accuracy_kmeans


# ------------------------------
# Plot the Model Accuracies
# ------------------------------
ggplot(data = model_accuracies, aes(x = Model, y = Accuracy, fill = Model)) +
  geom_bar(stat = "identity") +
  theme_minimal() +
  labs(title = "Model Accuracy Comparison (Vertebral Column Dataset)",
       x = "Model",
       y = "Accuracy") +
  geom_text(aes(label = round(Accuracy, 4)), vjust = -0.5, size = 4)

# Load required library for heatmap
library(ggplot2)

# Create a heatmap for model accuracies
accuracy_matrix <- as.matrix(model_accuracies$Accuracy)  # Convert the accuracy data to matrix format

# Plotting the heatmap
ggplot(data = model_accuracies, aes(x = Model, y = 1, fill = Accuracy)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "blue") +
  theme_minimal() +
  labs(title = "Model Accuracy Heatmap", x = "Model", y = "") +
  geom_text(aes(label = round(Accuracy, 4)), color = "black", size = 6, vjust = 0.5) +
  theme(axis.text.y = element_blank(), axis.title.y = element_blank())

